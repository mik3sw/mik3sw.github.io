"use client";

import { motion, Variants } from "framer-motion";
import { Button } from "@/components/ui/button";
import { COMPANY_INFO } from "@/lib/config/constants";
import { ArrowUpRightIcon, UsersIcon } from "lucide-react";
import {
  Terminal,
  TypingAnimation,
  AnimatedSpan,
} from '@/components/ui/shadcn-io/terminal';
import { Status, StatusIndicator, StatusLabel } from '@/components/ui/shadcn-io/status';
import { Magnetic } from "./ui/shadcn-io/magnetic";


export default function Hero() {
  // ✅ Tip explicito
  const container: Variants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
      },
    },
  };

  const item: Variants = {
    hidden: { opacity: 0, x: -40 },
    show: {
      opacity: 1,
      x: 0,
      transition: { duration: 0.6, ease: "easeOut" },
    },
  };

  return (
    <div>
      <div className="w-full h-screen flex flex-col items-center">
        <motion.div
          className="md:w-[80%] lg:w-[80%] w-[90%] flex justify-center items-center h-screen gap-7"
          variants={container}
          initial="hidden"
          animate="show"
        >
          <div className="flex-1 flex flex-col justify-center gap-7">
            <motion.div
              variants={item}
              className="rounded-md border px-4 py-2 font-mono text-sm w-fit flex items-center gap-2"
            >
              <UsersIcon />
              <div>Consulting and development</div>
              <Status status="online">
                <StatusIndicator />
                <StatusLabel />
              </Status>
            </motion.div>

            <motion.h1
              variants={item}
              className="scroll-m-10 md:text-6xl lg:text-6xl text-5xl font-bold tracking-tight text-balance max-w-3xl"
            >
              {COMPANY_INFO.motto}
            </motion.h1>

            <motion.span
              variants={item}
              className="scroll-m-10 text-xl font-normal tracking-tight text-balance text-gray-500 max-w-2xl"
            >
              {COMPANY_INFO.subtitle}
            </motion.span>

            <motion.div variants={item}>
              <Magnetic>
                <Button className="w-fit text-center font-normal" size="lg">
                  Learn More <ArrowUpRightIcon />
                </Button>
              </Magnetic>
            </motion.div>
          </div>


        <motion.div
          variants={item}
          className="flex-1 rounded-2xl hidden md:flex overflow-hidden relative h-100 shadow-lg"
        >
          {/* <img
            src="./3d.gif"
            alt="Descrizione immagine"
            className="w-full h-full object-cover"
          /> */}
          <Terminal className="w-full shadow-lg">
            <AnimatedSpan delay={0}>$ redix-informatica</AnimatedSpan>
            <TypingAnimation delay={800} duration={30}>
              🔧 Booting expert dev team...
            </TypingAnimation>
            <AnimatedSpan delay={2200}>✔️ Team ready for action</AnimatedSpan>
            <TypingAnimation delay={2300} duration={30}>
              💡 Loading innovative solutions...
            </TypingAnimation>
            <AnimatedSpan delay={3500}>✅ MVP deployed successfully</AnimatedSpan>
            <TypingAnimation delay={4300} duration={30}>
              🤖 Activating AI-powered features...
            </TypingAnimation>
            <TypingAnimation delay={5500} duration={30}>
              🌐 Connecting clients to the future...
            </TypingAnimation>
            <AnimatedSpan delay={7500}>🚀 Server ready at https://www.redix.it</AnimatedSpan>
            {/* <AnimatedSpan delay={8000}>$ npm run innovate</AnimatedSpan> */}
          </Terminal>
        </motion.div>
      </motion.div>
          
      </div>
    </div>
  );
}

export { Hero }
