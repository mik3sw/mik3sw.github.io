import React from 'react';
import { Logo } from './logo';
import { BotIcon, BrainIcon, ChartPieIcon, DatabaseIcon, ScanBarcodeIcon, ServerIcon, ShieldBanIcon, SquareTerminalIcon } from 'lucide-react';

const OrbitalCircles = () => {
  // Configurazione cerchi orbitali
  const innerOrbitCircles = [
    { dimensions: 'w-[50px] h-[50px]', color: 'bg-sky-500', rotation: 0, icon: DatabaseIcon},
    { dimensions: 'w-[50px] h-[50px]', color: 'bg-green-500', rotation: 120, icon: ShieldBanIcon},
    { dimensions: 'w-[50px] h-[50px]', color: 'bg-teal-500', rotation: 240, icon: ChartPieIcon},
    // { color: 'bg-red-600', rotation: 270 },
  ];

  const outerOrbitCircles = [
    { dimensions: 'w-[50px] h-[50px]', color: 'bg-orange-500', rotation: 0, icon: BrainIcon },
    { dimensions: 'w-[50px] h-[50px]', color: 'bg-blue-500', rotation: 72, icon: ScanBarcodeIcon },
    { dimensions: 'w-[50px] h-[50px]', color: 'bg-rose-500', rotation: 144, icon: BotIcon },
    { dimensions: 'w-[50px] h-[50px]', color: 'bg-yellow-500', rotation: 216, icon: ServerIcon },
    { dimensions: 'w-[50px] h-[50px]', color: 'bg-indigo-500', rotation: 288,icon: SquareTerminalIcon },
  ];

  return (
    <div className="flex items-center justify-center my-10">
      <div className="relative md:w-[400px] md:h-[400px] w-[300px] h-[300px]">
        {/* Cerchio esterno con bordo tratteggiato */}
        <div className="absolute inset-0 rounded-full border-2 border-dashed border-gray-300 dark:border-gray-500"></div>

        {/* 1. UNICO contenitore rotante per i cerchi ESTERNI */}
        <div
          className="absolute inset-0 animate-spin"
          style={{
            animationDuration: '20s',
            animationDirection: 'reverse',
          }}
        >
          {/* 2. Mappiamo i cerchi *dentro* il contenitore rotante */}
          {outerOrbitCircles.map((circle, index) => (
            <div
              key={ `outer-${index}`}
              className="absolute inset-0"
              style={{
                transform: `rotate(${circle.rotation}deg)`, 
              }}
            >
              {/* 4. Il cerchio vero e proprio, posizionato in cima al "raggio" */}
              <div
                className={`absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 rounded-full ${circle.color} shadow-lg ${circle.dimensions} flex items-center justify-center`}
              >{<circle.icon></circle.icon>}</div>
            </div>
          ))}
        </div>

        {/* Cerchio intermedio con bordo tratteggiato */}
        <div className="absolute inset-[80px] rounded-full border-2 border-dashed border-gray-300 dark:border-gray-500"></div>

        {/* 1. UNICO contenitore rotante per i cerchi INTERNI */}
        <div
          className="absolute inset-[80px] animate-spin"
          style={{
            animationDuration: '15s',
          }}
        >
          {/* 2. Mappiamo i cerchi *dentro* il contenitore rotante */}
          {innerOrbitCircles.map((circle, index) => (
            // 3. Questo div "raggio" imposta la posizione angolare fissa
            <div
              key={`inner-${index}`}
              className="absolute inset-0" // Occupa tutto lo spazio del genitore
              style={{
                transform: `rotate(${circle.rotation}deg)`, // Applica la rotazione iniziale
              }}
            >
              {/* 4. Il cerchio vero e proprio, posizionato in cima al "raggio" */}
              <div
                className={`absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 rounded-full ${circle.color} shadow-lg flex items-center justify-center ${circle.dimensions}`}
              >{<circle.icon></circle.icon>}</div>
            </div>
          ))}
        </div>

        {/* Cerchio centrale */}
        <div className="absolute inset-[120px] md:inset-[140px] lg:inset-[140px] rounded-full bg-primary shadow-2xl flex items-center justify-center">
          <Logo className='text-background w-[90%] h-[90%]'></Logo>
        </div>
      </div>
    </div>
  );
};

export default OrbitalCircles;