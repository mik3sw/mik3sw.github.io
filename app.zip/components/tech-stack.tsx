"use client";

import { motion, Variants, useInView } from "framer-motion";
import { useRef } from "react";
import { Button } from "@/components/ui/button";
import { COMPANY_INFO } from "@/lib/config/constants";
import {
  Terminal,
  TypingAnimation,
  AnimatedSpan,
} from '@/components/ui/shadcn-io/terminal';
import { Status, StatusIndicator, StatusLabel } from '@/components/ui/shadcn-io/status';
import {UsersIcon, LightbulbIcon, HandshakeIcon, FlaskConicalIcon, TimerIcon, DnaIcon, ArrowRightIcon } from 'lucide-react'
import Features from "./ui/feature-section";
import OrbitalCircles from "./ui/orbital-circle";

export default function TechStack() {
  const sectionRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true, amount: 0.2 });

  const fadeInLeft: Variants = {
    hidden: { opacity: 0, x: -60 },
    show: {
      opacity: 1,
      x: 0,
      transition: { duration: 0.7, ease: "easeOut" },
    },
  };

  const fadeInUp: Variants = {
    hidden: { opacity: 0, y: 60 },
    show: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.7, ease: "easeOut" },
    },
  };

  return (
    <section ref={sectionRef} className='py-8 overflow-hidden mb-30'>
      <div className="flex items-center justify-center mx-auto flex-col-reverse md:flex-row lg:flex-row md:w-[80%] lg:w-[80%] w-[90%]">
        <motion.div
          className='flex-1'
          variants={fadeInUp}
          initial="hidden"
          animate={isInView ? "show" : "hidden"}
        >
          <OrbitalCircles />
        </motion.div>

        <div className='flex-1'>
          {/* Header */}
          <div className='mb-12 space-y-4 sm:mb-16 lg:mb-24'>
            <motion.h2
              className='text-2xl font-semibold md:text-3xl lg:text-4xl'
              variants={fadeInLeft}
              initial="hidden"
              animate={isInView ? "show" : "hidden"}
              transition={{ delay: 0.1 }}
            >
              Our Tech Stack, Your Competitive Edge
            </motion.h2>

            <motion.p
              className='text-muted-foreground text-xl'
              variants={fadeInLeft}
              initial="hidden"
              animate={isInView ? "show" : "hidden"}
              transition={{ delay: 0.3 }}
            >
              From dynamic front-end interfaces to robust back-end architectures, our stack is built for performance and scalability. We combine solid data foundations with secure private AI to deliver intelligent, future-ready solutions tailored to your business.
            </motion.p>

            <motion.div
              variants={fadeInLeft}
              initial="hidden"
              animate={isInView ? "show" : "hidden"}
              transition={{ delay: 0.5 }}
            >
              <Button variant='outline' className='rounded-lg text-base shadow-none has-[>svg]:px-6' size='lg' asChild>
                <a href='#'>
                  Get in touch
                  <ArrowRightIcon />
                </a>
              </Button>
            </motion.div>
          </div>
        </div>

        
      </div>
    </section>
  );
}

export { TechStack }