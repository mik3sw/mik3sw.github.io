import About from "@/components/about";
import Hero from "@/components/hero";
import TechStack from "@/components/tech-stack";
import { Button } from "@/components/ui/button";
import { COMPANY_INFO } from "@/lib/config/constants";
import { ArrowUpRightIcon, CodeXmlIcon, UsersIcon } from "lucide-react";

export default function Home() {
  return (
    // <div>
    // <div className="w-full h-screen flex flex-col items-center">
    //   <div className="w-[80%] flex justify-center items-center h-screen gap-7">
    //     <div className="flex-1 flex flex-col justify-center gap-7">
    //       <div className="rounded-md border px-4 py-2 font-mono text-sm w-fit flex items-center gap-2">
    //       <UsersIcon></UsersIcon><div>Consulting and development</div>
    //       </div>
    //       <h1 className="scroll-m-10 text-6xl font-bold tracking-tight text-balance max-w-3xl">
    //         {COMPANY_INFO.motto}
    //       </h1>
    //       <span className="scroll-m-10 text-xl font-normal tracking-tight text-balance text-gray-500 max-w-2xl">
    //         {COMPANY_INFO.subtitle}
    //       </span>
    //       <Button className="w-fit text-center font-normal" size="lg">Learn More <ArrowUpRightIcon /></Button>
    //     </div>
    //     <div className="flex-1 flex flex-col justify-center gap-7 bg-primary h-[500px] rounded-2xl"></div>
    //   </div>
    // </div>
    // <div className="w-full flex flex-col items-center h-screen"></div>
    // </div>
    <div>
      <Hero></Hero>
      <TechStack></TechStack>
      <About></About>
      
    </div>
    

  );
}
