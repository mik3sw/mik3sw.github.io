export const COMPANY_INFO = {
    name: "Redix",
    motto: "Let’s design your innovation together",
    subtitle: "Our experience at the service of your innovation: we’ve been offering highly customized solutions in the business, publishing and public administration fields for over 30 years."
} as const


